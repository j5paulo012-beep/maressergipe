import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  tides: router({
    brazil: publicProcedure
      .input(z.object({
        state: z.string().regex(/^[a-z]{2}$/),
        lat: z.number(),
        lng: z.number(),
        month: z.number().int().min(1).max(12),
        day: z.number().int().min(1).max(31),
      }))
      .query(async ({ input }) => {
        const lastDay = new Date(new Date().getFullYear(), input.month, 0).getDate();
        const endDay = Math.min(input.day + 6, lastDay);
        const days = `[${input.day}-${endDay}]`;
        const url = `https://tabuamare.api.br/api/v2/geo-tabua-mare/[${input.lat},${input.lng}]/${input.state}/${input.month}/${days}`;
        const response = await fetch(url);
        if (!response.ok) throw new Error("A API brasileira de marés não respondeu.");
        return response.json();
      }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
