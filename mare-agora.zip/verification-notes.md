## Verificação visual

A interface exibe os 17 estados costeiros em chips, sete datas futuras, relógio em tempo real, estado selecionado (Sergipe), referência do porto mais próximo, botão para o site oficial da Marinha e estado de carregamento enquanto o proxy consulta a API brasileira. Em capturas anteriores após a resposta do servidor, o cartão de maré exibiu dados reais de Aracaju/Sergipe; a captura final foi feita durante uma nova consulta e mostrou corretamente o spinner.

## Verificação técnica

`pnpm test` passou com 2 testes de maré; o teste legado de autenticação permanece marcado como skipped pelo template. `pnpm check` passou sem erros TypeScript. O proxy tRPC foi criado para evitar CORS no navegador.

## Diagnóstico adicional

O proxy HTTPS respondeu com status 200 quando testado diretamente no navegador. Como o hook tRPC não disparava a consulta no preview, a tela foi ajustada para usar `fetch` manual no endpoint tRPC, mantendo o proxy no servidor e evitando CORS em web e mobile.

## Alertas inteligentes

A tela mantém os seletores de estados, calendário ampliado e painel de aparência. O novo painel permite escolher Pesca, Surf, Passeio na praia ou Passeio de barco, ativar/desativar avisos e exibe o status do agendamento. A implementação usa notificações locais do Expo, solicitando permissão somente ao ativar; no navegador, informa que os alertas ficam disponíveis no app instalado.

## Validação atualizada

Os testes de regras de atividade e cálculo de maré passaram, e o TypeScript não apresenta erros.

## Verificação visual dos alertas

No preview, o painel de configurações exibiu o bloco “Alertas inteligentes” com status DESATIVADOS, quatro atividades (Pesca, Surf, Passeio na praia e Passeio de barco) e o botão “Ativar alertas”.

## Correção de alertas em tempo real

O cartão “Alertas inteligentes” agora aparece diretamente na tela principal, com os botões “Configurar alertas” e “Testar”. O agendamento usa os próximos eventos reais retornados pela API brasileira, incluindo horários de maré cheia e seca, e é atualizado junto com a consulta periódica de cinco minutos. O cartão mostra a quantidade de horários reais programados quando ativo.
