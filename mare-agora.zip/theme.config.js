/** @type {const} */
const themeColors = {
  primary: { light: '#087F9B', dark: '#5CD8EA' },
  background: { light: '#F6FBFC', dark: '#0C1B20' },
  surface: { light: '#FFFFFF', dark: '#14272D' },
  foreground: { light: '#102A32', dark: '#F1FBFC' },
  muted: { light: '#6B8188', dark: '#9CB2B8' },
  border: { light: '#D9E9ED', dark: '#28434B' },
  success: { light: '#1A9B70', dark: '#58D9A5' },
  warning: { light: '#D98821', dark: '#F7BE65' },
  error: { light: '#D94B57', dark: '#FF7D87' },
};

module.exports = { themeColors };
