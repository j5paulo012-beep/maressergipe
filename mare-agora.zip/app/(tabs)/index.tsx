import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Linking,
  Modal,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColorScheme } from "@/hooks/use-color-scheme";
import { useColors } from "@/hooks/use-colors";
import { getApiBaseUrl } from "@/constants/oauth";
import * as Location from "expo-location";
import { useThemeContext } from "@/lib/theme-provider";
import { deriveTideState, type TideEvent } from "@/shared/tide";
import { getSmartActivity, getSmartAlertEvents, SMART_ACTIVITIES, type SmartActivity } from "@/shared/smart-alerts";
import * as Notifications from "expo-notifications";

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldShowBanner: true, shouldShowList: true, shouldPlaySound: false, shouldSetBadge: false }),
});

type BrazilState = { code: string; name: string; city: string; coordinates: [number, number] };

const BRAZIL_STATES: BrazilState[] = [
  { code: "al", name: "Alagoas", city: "Maceió", coordinates: [-9.6658, -35.7353] },
  { code: "ap", name: "Amapá", city: "Macapá", coordinates: [0.0349, -51.0694] },
  { code: "ba", name: "Bahia", city: "Salvador", coordinates: [-12.9777, -38.5016] },
  { code: "ce", name: "Ceará", city: "Fortaleza", coordinates: [-3.7319, -38.5267] },
  { code: "es", name: "Espírito Santo", city: "Vitória", coordinates: [-20.3155, -40.3128] },
  { code: "ma", name: "Maranhão", city: "São Luís", coordinates: [-2.5307, -44.3068] },
  { code: "pa", name: "Pará", city: "Belém", coordinates: [-1.4558, -48.4902] },
  { code: "pb", name: "Paraíba", city: "João Pessoa", coordinates: [-7.1195, -34.8450] },
  { code: "pe", name: "Pernambuco", city: "Recife", coordinates: [-8.0476, -34.8770] },
  { code: "pi", name: "Piauí", city: "Luís Correia", coordinates: [-2.8790, -41.6660] },
  { code: "pr", name: "Paraná", city: "Paranaguá", coordinates: [-25.5163, -48.5225] },
  { code: "rj", name: "Rio de Janeiro", city: "Rio de Janeiro", coordinates: [-22.9068, -43.1729] },
  { code: "rn", name: "Rio Grande do Norte", city: "Natal", coordinates: [-5.7793, -35.2009] },
  { code: "rs", name: "Rio Grande do Sul", city: "Rio Grande", coordinates: [-32.0350, -52.0986] },
  { code: "sc", name: "Santa Catarina", city: "Florianópolis", coordinates: [-27.5954, -48.5480] },
  { code: "se", name: "Sergipe", city: "Aracaju", coordinates: [-10.9472, -37.0731] },
  { code: "sp", name: "São Paulo", city: "Santos", coordinates: [-23.9608, -46.3336] },
];

function parseTideDate(value: string) {
  return new Date(value.replace(" ", "T"));
}

function formatTime(value: string | Date) {
  const date = typeof value === "string" ? parseTideDate(value) : value;
  return new Intl.DateTimeFormat("pt-BR", { hour: "2-digit", minute: "2-digit" }).format(date);
}

function formatDate(value: string) {
  const date = parseTideDate(value);
  return new Intl.DateTimeFormat("pt-BR", { weekday: "short", day: "2-digit", month: "short" }).format(date).replace(".", "");
}

function formatClock(value: Date) {
  return new Intl.DateTimeFormat("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }).format(value);
}

function formatDateChip(value: Date) {
  return new Intl.DateTimeFormat("pt-BR", { weekday: "short", day: "2-digit", month: "short" }).format(value).replace(".", "");
}

function parseBrazilTideEvents(payload: any): TideEvent[] {
  const data = payload?.data?.[0];
  const raw = data?.months?.flatMap((month: any) => (month.days ?? []).flatMap((day: any) => (day.hours ?? []).map((hour: any) => ({
    t: `${data.year}-${String(month.month).padStart(2, "0")}-${String(day.day).padStart(2, "0")} ${String(hour.hour).slice(0, 5)}`,
    v: String(hour.level),
  })))) ?? [];
  return raw.map((event: { t: string; v: string }, index: number) => {
    const previous = raw[index - 1] ? Number(raw[index - 1].v) : Number(event.v);
    const next = raw[index + 1] ? Number(raw[index + 1].v) : Number(event.v);
    const level = Number(event.v);
    return { ...event, type: level >= previous && level >= next ? "H" : "L" } as TideEvent;
  }).filter((event: TideEvent, index: number, list: TideEvent[]) => index === 0 || event.type !== list[index - 1].type);
}

function nearestCoastalState(latitude: number, longitude: number) {
  return BRAZIL_STATES.reduce((nearest, state) => {
    const distance = (state.coordinates[0] - latitude) ** 2 + (state.coordinates[1] - longitude) ** 2;
    const nearestDistance = (nearest.coordinates[0] - latitude) ** 2 + (nearest.coordinates[1] - longitude) ** 2;
    return distance < nearestDistance ? state : nearest;
  });
}

export default function HomeScreen() {
  const colors = useColors();
  const colorScheme = useColorScheme() ?? "light";
  const { setColorScheme } = useThemeContext();
  const [settingsVisible, setSettingsVisible] = useState(false);
  const [calendarVisible, setCalendarVisible] = useState(false);
  const [fontScale, setFontScale] = useState(1);
  const [accentColor, setAccentColor] = useState("#0B8DA3");
  const [alertIcon, setAlertIcon] = useState<"waves" | "notifications-active">("waves");
  const [smartActivity, setSmartActivity] = useState<SmartActivity>("pesca");
  const [smartAlertsEnabled, setSmartAlertsEnabled] = useState(false);
  const [smartAlertMessage, setSmartAlertMessage] = useState("Escolha uma atividade para receber avisos");
  const [scheduledAlertCount, setScheduledAlertCount] = useState(0);
  const scheduledAlertIds = useRef<string[]>([]);
  const [selectedState, setSelectedState] = useState(BRAZIL_STATES.find((state) => state.code === "se") ?? BRAZIL_STATES[0]);
  const [selectedDate, setSelectedDate] = useState(() => new Date());
  const [locationMessage, setLocationMessage] = useState("Usar minha localização");
  const [locating, setLocating] = useState(false);
  const [events, setEvents] = useState<TideEvent[]>([]);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const [clock, setClock] = useState(new Date());
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadTides = useCallback(async () => {
    try {
      setError(null);
      const input = {
        state: selectedState.code,
        lat: selectedState.coordinates[0],
        lng: selectedState.coordinates[1],
        month: selectedDate.getMonth() + 1,
        day: selectedDate.getDate(),
      };
      const query = encodeURIComponent(JSON.stringify({ json: input }));
      const response = await fetch(`${getApiBaseUrl()}/api/trpc/tides.brazil?input=${query}`);
      if (!response.ok) throw new Error("Não foi possível consultar a estação.");
      const envelope = await response.json();
      const brazilEvents = parseBrazilTideEvents(envelope?.result?.data?.json ?? envelope?.result?.data);
      if (!brazilEvents.length) throw new Error("Este estado não retornou previsões para o período.");
      setEvents(brazilEvents);
      setUpdatedAt(new Date());
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Erro ao buscar dados.");
    }
  }, [selectedDate, selectedState]);

  useEffect(() => {
    const clockTimer = setInterval(() => setClock(new Date()), 1000);
    loadTides();
    const tideTimer = setInterval(loadTides, 5 * 60 * 1000);
    return () => { clearInterval(clockTimer); clearInterval(tideTimer); };
  }, [loadTides]);

  const detectLocation = useCallback(async () => {
    try {
      setLocating(true);
      setLocationMessage("Localizando…");
      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== "granted") {
        setLocationMessage("Permissão de localização negada");
        return;
      }
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const nearest = nearestCoastalState(position.coords.latitude, position.coords.longitude);
      setSelectedState(nearest);
      setLocationMessage(`Localização: ${nearest.name}`);
    } catch {
      setLocationMessage("Não foi possível localizar");
    } finally {
      setLocating(false);
    }
  }, []);

  useEffect(() => {
    detectLocation();
  }, [detectLocation]);

  const tide = useMemo(() => {
    if (!events.length) return null;
    const previewMoment = new Date(selectedDate);
    previewMoment.setHours(selectedDate.toDateString() === new Date().toDateString() ? new Date().getHours() : 12, selectedDate.toDateString() === new Date().toDateString() ? new Date().getMinutes() : 0, 0, 0);
    return deriveTideState(events, previewMoment);
  }, [events, selectedDate]);

  const dateOptions = useMemo(() => Array.from({ length: 30 }, (_, index) => {
    const date = new Date();
    date.setHours(12, 0, 0, 0);
    date.setDate(date.getDate() + index);
    return date;
  }), []);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadTides();
    setRefreshing(false);
  };

  const cancelSmartAlerts = useCallback(async () => {
    if (Platform.OS !== "web") {
      await Promise.all(scheduledAlertIds.current.map((id) => Notifications.cancelScheduledNotificationAsync(id)));
    }
    scheduledAlertIds.current = [];
    setScheduledAlertCount(0);
    setSmartAlertsEnabled(false);
    setSmartAlertMessage("Alertas inteligentes desativados");
  }, []);

  const scheduleSmartAlerts = useCallback(async () => {
    if (Platform.OS === "web") {
      setSmartAlertMessage("Alertas ficam disponíveis no app instalado");
      return;
    }
    if (!events.length) {
      setSmartAlertMessage("Aguardando a previsão da estação");
      return;
    }
    try {
      const currentPermissions = await Notifications.getPermissionsAsync();
      const permission = currentPermissions.status === "granted" ? currentPermissions : await Notifications.requestPermissionsAsync();
      if (permission.status !== "granted") {
        setSmartAlertMessage("Permissão de notificações negada. Ative nas configurações do celular.");
        return;
      }
      if (Platform.OS === "android") {
        await Notifications.setNotificationChannelAsync("tide-alerts", { name: "Alertas de maré", importance: Notifications.AndroidImportance.HIGH, sound: "default" });
      }
      await Promise.all(scheduledAlertIds.current.map((id) => Notifications.cancelScheduledNotificationAsync(id)));
      const selectedActivity = getSmartActivity(smartActivity);
      const alertEvents = getSmartAlertEvents(events, smartActivity, new Date());
      const ids: string[] = [];
      for (const alert of alertEvents) {
        const date = new Date(alert.event.t.replace(" ", "T"));
        if (date.getTime() <= Date.now()) continue;
        const id = await Notifications.scheduleNotificationAsync({
          content: { title: alert.title, body: `${alert.body} ${selectedState.city} · ${formatDate(alert.event.t)} às ${formatTime(alert.event.t)}`, sound: "default", data: { type: "smart-tide-alert", activity: smartActivity, event: alert.event } },
          trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date, channelId: "tide-alerts" },
        });
        ids.push(id);
      }
      scheduledAlertIds.current = ids;
      setScheduledAlertCount(ids.length);
      setSmartAlertsEnabled(ids.length > 0);
      setSmartAlertMessage(ids.length ? `${ids.length} horários reais programados para ${selectedActivity.label.toLowerCase()}` : "Nenhum horário futuro encontrado");
    } catch {
      setSmartAlertMessage("Não foi possível programar. Reabra o app e permita notificações.");
    }
  }, [events, selectedState.city, smartActivity]);

  const testSmartNotification = useCallback(async () => {
    if (Platform.OS === "web") {
      setSmartAlertMessage("O teste funciona no app instalado, não no preview web");
      return;
    }
    try {
      const currentPermissions = await Notifications.getPermissionsAsync();
      const permission = currentPermissions.status === "granted" ? currentPermissions : await Notifications.requestPermissionsAsync();
      if (permission.status !== "granted") {
        setSmartAlertMessage("Permissão de notificações negada. Ative nas configurações do celular.");
        return;
      }
      if (Platform.OS === "android") await Notifications.setNotificationChannelAsync("tide-alerts", { name: "Alertas de maré", importance: Notifications.AndroidImportance.HIGH, sound: "default" });
      await Notifications.scheduleNotificationAsync({ content: { title: "Tábua de Maré", body: "Teste recebido. Seus alertas inteligentes estão funcionando.", sound: "default" }, trigger: { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds: 5, repeats: false, channelId: "tide-alerts" } });
      setSmartAlertMessage("Teste programado: a notificação aparecerá em 5 segundos");
    } catch {
      setSmartAlertMessage("Falha no teste. Instale uma versão nativa atualizada do app.");
    }
  }, []);

  useEffect(() => {
    if (smartAlertsEnabled && events.length) scheduleSmartAlerts();
  }, [events, scheduleSmartAlerts, smartAlertsEnabled]);

  return (
    <ScreenContainer containerClassName="bg-background" className="px-5">
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
      >
        <View style={styles.header}>
          <View>
            <Text style={[styles.eyebrow, { color: accentColor }]}>TÁBUA DE MARÉ</Text>
            <Text style={[styles.title, { color: colors.foreground, fontSize: 30 * fontScale, lineHeight: 36 * fontScale }]}>Como está o mar?</Text>
          </View>
          <View style={styles.headerActions}>
            <Text style={[styles.clockText, { color: colors.muted }]}>{formatClock(clock)}</Text>
            <Pressable
              accessibilityLabel="Alternar tema claro e escuro"
              onPress={() => setColorScheme(colorScheme === "dark" ? "light" : "dark")}
              style={({ pressed }) => [styles.themeButton, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}
            >
              <MaterialIcons name={colorScheme === "dark" ? "light-mode" : "dark-mode"} size={17} color={colors.foreground} />
            </Pressable>
            <Pressable
              accessibilityLabel="Abrir configurações de aparência"
              hitSlop={10}
              onPress={() => setSettingsVisible(true)}
              style={({ pressed }) => [styles.themeButton, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}
            >
              <MaterialIcons name="tune" size={17} color={colors.foreground} />
            </Pressable>
            <View style={[styles.livePill, { backgroundColor: `${colors.success}18` }]}> 
              <View style={[styles.liveDot, { backgroundColor: colors.success }]} />
              <Text style={[styles.liveText, { color: colors.success }]}>AO VIVO</Text>
            </View>
          </View>
        </View>

        <View style={[styles.statePickerCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.statePickerHeader}>
            <View>
              <Text style={[styles.statePickerLabel, { color: colors.muted }]}>LOCALIZAÇÃO</Text>
              <Text style={[styles.statePickerTitle, { color: colors.foreground }]}>Escolha um estado costeiro</Text>
            </View>
            <MaterialIcons name="public" size={22} color={colors.primary} />
          </View>
          <FlatList
            data={BRAZIL_STATES}
            horizontal
            showsHorizontalScrollIndicator={false}
            keyExtractor={(item) => item.code}
            contentContainerStyle={styles.stateList}
            renderItem={({ item }) => {
              const selected = item.code === selectedState.code;
              return (
                <Pressable
                  accessibilityLabel={`Selecionar ${item.name}`}
                  onPress={() => setSelectedState(item)}
                  style={({ pressed }) => [styles.stateChip, { backgroundColor: selected ? accentColor : colors.background, borderColor: selected ? accentColor : colors.border }, pressed && styles.pressed]}
                >
                  <Text style={[styles.stateChipText, { color: selected ? "#FFFFFF" : colors.foreground }]}>{item.code.toUpperCase()}</Text>
                </Pressable>
              );
            }}
          />
          <Pressable
            accessibilityLabel="Usar minha localização atual"
            onPress={detectLocation}
            style={({ pressed }) => [styles.locationButton, { backgroundColor: `${colors.primary}10`, borderColor: `${colors.primary}35` }, pressed && styles.pressed]}
          >
            <MaterialIcons name={locating ? "gps-fixed" : "my-location"} size={16} color={colors.primary} />
            <Text style={[styles.locationButtonText, { color: colors.primary }]}>{locating ? "Buscando localização…" : locationMessage}</Text>
          </Pressable>
        </View>

        <View style={[styles.datePickerCard, { backgroundColor: colors.surface, borderColor: colors.border }]}> 
          <View style={styles.statePickerHeader}>
            <View>
              <Text style={[styles.statePickerLabel, { color: colors.muted }]}>DATA DA MARÉ</Text>
              <Text style={[styles.statePickerTitle, { color: colors.foreground }]}>Escolha o dia da previsão</Text>
            </View>
            <Pressable accessibilityLabel="Abrir calendário" onPress={() => setCalendarVisible(true)} style={({ pressed }) => [styles.calendarButton, { backgroundColor: `${accentColor}12` }, pressed && styles.pressed]}>
              <MaterialIcons name="calendar-today" size={20} color={accentColor} />
            </Pressable>
          </View>
          <FlatList
            data={dateOptions}
            horizontal
            showsHorizontalScrollIndicator={false}
            keyExtractor={(item) => item.toISOString()}
            contentContainerStyle={styles.stateList}
            renderItem={({ item }) => {
              const selected = item.toDateString() === selectedDate.toDateString();
              return (
                <Pressable
                  accessibilityLabel={`Selecionar ${formatDateChip(item)}`}
                  onPress={() => setSelectedDate(item)}
                  style={({ pressed }) => [styles.dateChip, { backgroundColor: selected ? accentColor : colors.background, borderColor: selected ? accentColor : colors.border }, pressed && styles.pressed]}
                >
                  <Text style={[styles.dateChipText, { color: selected ? "#FFFFFF" : colors.foreground }]}>{formatDateChip(item)}</Text>
                </Pressable>
              );
            }}
          />
        </View>

        <View style={[styles.smartCard, { backgroundColor: colors.surface, borderColor: colors.border }]}> 
          <View style={styles.smartCardHeader}>
            <View style={[styles.smartCardIcon, { backgroundColor: `${accentColor}15` }]}><MaterialIcons name="notifications-active" size={20} color={accentColor} /></View>
            <View style={styles.smartCardCopy}><Text style={[styles.smartCardTitle, { color: colors.foreground }]}>Alertas inteligentes</Text><Text style={[styles.smartCardSubtitle, { color: colors.muted }]}>{smartAlertsEnabled ? "Ativos no celular" : "Maré seca e pico ideal por atividade"}</Text></View>
            <View style={[styles.smartStatus, { backgroundColor: smartAlertsEnabled ? `${colors.success}18` : `${colors.muted}15` }]}><Text style={{ color: smartAlertsEnabled ? colors.success : colors.muted, fontSize: 9, fontWeight: "900" }}>{smartAlertsEnabled ? `${scheduledAlertCount} ATIVOS` : "OFF"}</Text></View>
          </View>
          <Text style={[styles.smartCardMessage, { color: colors.muted }]}>{smartAlertMessage}</Text>
          <View style={styles.smartCardActions}>
            <Pressable accessibilityLabel="Configurar alertas inteligentes" onPress={() => setSettingsVisible(true)} style={({ pressed }) => [styles.smartCardPrimary, { backgroundColor: accentColor }, pressed && styles.pressed]}><MaterialIcons name="tune" size={16} color="#FFFFFF" /><Text style={styles.smartPrimaryText}>Configurar alertas</Text></Pressable>
            <Pressable accessibilityLabel="Testar notificação" onPress={testSmartNotification} style={({ pressed }) => [styles.smartCardSecondary, { borderColor: accentColor }, pressed && styles.pressed]}><MaterialIcons name="notifications-none" size={16} color={accentColor} /><Text style={[styles.smartTestText, { color: accentColor }]}>Testar</Text></Pressable>
          </View>
        </View>

        <View style={[styles.stationCard, { backgroundColor: colors.surface, borderColor: colors.border }]}> 
          <View style={[styles.stationIcon, { backgroundColor: `${colors.primary}18` }]}>
            <MaterialIcons name="location-on" size={19} color={colors.primary} />
          </View>
          <View style={styles.stationCopy}>
            <Text style={[styles.stationName, { color: colors.foreground }]}>{selectedState.city} · {selectedState.name}</Text>
            <Text style={[styles.stationSubtitle, { color: colors.muted }]}>Porto mais próximo · API brasileira · Atualiza a cada 5 min</Text>
          </View>
          <MaterialIcons name="keyboard-arrow-down" size={22} color={colors.muted} />
        </View>

        <Pressable
          onPress={() => Linking.openURL("https://www.marinha.mil.br/chm/dados-do-segnav/dados-de-mare-mapa")}
          style={({ pressed }) => [styles.officialButton, { backgroundColor: `${colors.primary}12`, borderColor: `${colors.primary}35` }, pressed && styles.pressed]}
        >
          <MaterialIcons name="open-in-new" size={17} color={colors.primary} />
          <Text style={[styles.officialButtonText, { color: colors.primary }]}>Abrir site oficial da Tábua de Maré</Text>
          <MaterialIcons name="chevron-right" size={18} color={colors.primary} />
        </Pressable>

        {error ? (
          <View style={[styles.errorCard, { backgroundColor: `${colors.error}12`, borderColor: `${colors.error}40` }]}>
            <MaterialIcons name="cloud-off" size={20} color={colors.error} />
            <Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>
            <Pressable onPress={loadTides} style={({ pressed }) => [styles.retryButton, pressed && styles.pressed]}>
              <Text style={[styles.retryText, { color: colors.error }]}>Tentar de novo</Text>
            </Pressable>
          </View>
        ) : tide ? (
          <>
            <View style={[styles.heroCard, { backgroundColor: colors.primary }]}> 
              <View style={styles.heroTopRow}>
                <View>
                  <Text style={styles.heroLabel}>STATUS DA MARÉ</Text>
                <Text style={[styles.heroStatus, { fontSize: 32 * fontScale }]}>{tide.status}</Text>
                </View>
                <MaterialIcons name={tide.status === "Secando" ? "south" : "north"} size={44} color="#D7F8FF" />
              </View>
              <View style={styles.levelRow}>
                <Text style={styles.levelValue}>{tide.level.toFixed(2).replace(".", ",")}</Text>
                <Text style={styles.levelUnit}>m agora</Text>
              </View>
              <View style={styles.waveTrack}>
                <View style={[styles.waveFill, { width: `${Math.max(8, Math.min(94, tide.level * 100))}%` }]} />
              </View>
              <Text style={styles.heroHint}>Entre {tide.status === "Enchendo" ? "a maré seca" : "a maré cheia"} e a próxima virada · fonte DHN</Text>
            </View>

            {tide.isAtExtreme && (
              <View style={[styles.extremeAlert, { backgroundColor: tide.extremeType === "H" ? `${colors.warning}18` : `${colors.primary}18`, borderColor: tide.extremeType === "H" ? `${colors.warning}55` : `${colors.primary}55` }]}>
                <View style={[styles.extremeAlertIcon, { backgroundColor: tide.extremeType === "H" ? `${colors.warning}24` : `${colors.primary}24` }]}>
                  <MaterialIcons name={alertIcon} size={21} color={tide.extremeType === "H" ? colors.warning : accentColor} />
                </View>
                <View style={styles.extremeAlertCopy}>
                  <Text style={[styles.extremeAlertTitle, { color: colors.foreground }]}>{tide.extremeType === "H" ? "Maré completamente cheia" : "Maré completamente seca"}</Text>
                  <Text style={[styles.extremeAlertText, { color: colors.muted }]}>A maré atingiu o nível máximo previsto agora.</Text>
                </View>
                <View style={[styles.alertBadge, { backgroundColor: tide.extremeType === "H" ? colors.warning : colors.primary }]}>
                  <Text style={styles.alertBadgeText}>AGORA</Text>
                </View>
              </View>
            )}

            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Próximas mudanças</Text>
            <View style={styles.changeGrid}>
              <View style={[styles.changeCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <View style={[styles.changeIcon, { backgroundColor: `${colors.success}18` }]}><MaterialIcons name="south-west" size={18} color={colors.success} /></View>
                <Text style={[styles.changeLabel, { color: colors.muted }]}>Começa a encher</Text>
                <Text style={[styles.changeTime, { color: colors.foreground }]}>{tide.nextHigh ? formatTime(tide.nextHigh.t) : "—"}</Text>
                <Text style={[styles.changeDate, { color: colors.muted }]}>{tide.nextHigh ? formatDate(tide.nextHigh.t) : "sem previsão"}</Text>
              </View>
              <View style={[styles.changeCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <View style={[styles.changeIcon, { backgroundColor: `${colors.warning}18` }]}><MaterialIcons name="south-east" size={18} color={colors.warning} /></View>
                <Text style={[styles.changeLabel, { color: colors.muted }]}>Começa a secar</Text>
                <Text style={[styles.changeTime, { color: colors.foreground }]}>{tide.nextLow ? formatTime(tide.nextLow.t) : "—"}</Text>
                <Text style={[styles.changeDate, { color: colors.muted }]}>{tide.nextLow ? formatDate(tide.nextLow.t) : "sem previsão"}</Text>
              </View>
            </View>

            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Previsão da estação</Text>
            <View style={[styles.listCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              {tide.upcoming.map((event, index) => {
                const high = event.type === "H";
                return (
                  <View key={`${event.t}-${event.type}`} style={[styles.eventRow, index < tide.upcoming.length - 1 && { borderBottomColor: colors.border, borderBottomWidth: StyleSheet.hairlineWidth }]}>
                    <View style={[styles.eventIcon, { backgroundColor: high ? `${colors.primary}18` : `${colors.warning}18` }]}><MaterialIcons name={high ? "arrow-upward" : "arrow-downward"} size={16} color={high ? colors.primary : colors.warning} /></View>
                    <View style={styles.eventMain}><Text style={[styles.eventType, { color: colors.foreground }]}>{high ? "Maré cheia" : "Maré seca"}</Text><Text style={[styles.eventDate, { color: colors.muted }]}>{formatDate(event.t)}</Text></View>
                    <View style={styles.eventRight}><Text style={[styles.eventTime, { color: colors.foreground }]}>{formatTime(event.t)}</Text><Text style={[styles.eventLevel, { color: colors.muted }]}>{Number(event.v).toFixed(2).replace(".", ",")} m</Text></View>
                  </View>
                );
              })}
            </View>
          </>
        ) : (
          <View style={styles.loadingState}><ActivityIndicator size="large" color={colors.primary} /><Text style={[styles.loadingText, { color: colors.muted }]}>Buscando a maré atual…</Text></View>
        )}

        <View style={styles.footerRow}>
          <MaterialIcons name="update" size={14} color={colors.muted} />
          <Text style={[styles.footerText, { color: colors.muted }]}>{updatedAt ? `Atualizado às ${formatTime(updatedAt)}` : "Conectando à estação"}</Text>
        </View>
        <Text style={[styles.developerText, { color: colors.muted }]}>Desenvolvido por Paulo do Siri</Text>
      </ScrollView>

      <Modal visible={calendarVisible} transparent animationType="slide" onRequestClose={() => setCalendarVisible(false)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { backgroundColor: colors.surface }]}> 
            <View style={styles.modalHeader}>
              <View><Text style={[styles.modalEyebrow, { color: accentColor }]}>CALENDÁRIO</Text><Text style={[styles.modalTitle, { color: colors.foreground }]}>Escolha o dia da maré</Text></View>
              <Pressable onPress={() => setCalendarVisible(false)} style={styles.modalClose}><MaterialIcons name="close" size={21} color={colors.foreground} /></Pressable>
            </View>
            <View style={styles.calendarGrid}>
              {dateOptions.map((item) => {
                const selected = item.toDateString() === selectedDate.toDateString();
                return <Pressable key={item.toISOString()} onPress={() => { setSelectedDate(item); setCalendarVisible(false); }} style={[styles.calendarDay, { backgroundColor: selected ? accentColor : colors.background, borderColor: selected ? accentColor : colors.border }]}><Text style={[styles.calendarDayText, { color: selected ? "#FFFFFF" : colors.foreground }]}>{item.getDate()}</Text><Text style={[styles.calendarWeekday, { color: selected ? "#FFFFFF" : colors.muted }]}>{new Intl.DateTimeFormat("pt-BR", { weekday: "short" }).format(item).replace(".", "")}</Text></Pressable>;
              })}
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={settingsVisible} transparent animationType="slide" onRequestClose={() => setSettingsVisible(false)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { backgroundColor: colors.surface }]}> 
            <View style={styles.modalHeader}><View><Text style={[styles.modalEyebrow, { color: accentColor }]}>APARÊNCIA</Text><Text style={[styles.modalTitle, { color: colors.foreground }]}>Configurações</Text></View><Pressable onPress={() => setSettingsVisible(false)} style={styles.modalClose}><MaterialIcons name="close" size={21} color={colors.foreground} /></Pressable></View>
            <Text style={[styles.settingLabel, { color: colors.muted }]}>Tamanho da letra</Text>
            <View style={styles.settingRow}>{[[1, "Normal"], [1.15, "Grande"]].map(([value, label]) => <Pressable key={String(value)} onPress={() => setFontScale(Number(value))} style={[styles.settingOption, { backgroundColor: fontScale === value ? accentColor : colors.background, borderColor: fontScale === value ? accentColor : colors.border }]}><Text style={{ color: fontScale === value ? "#FFFFFF" : colors.foreground, fontWeight: "700" }}>{label}</Text></Pressable>)}</View>
            <Text style={[styles.settingLabel, { color: colors.muted }]}>Cor de destaque</Text>
            <View style={styles.settingRow}>{["#0B8DA3", "#1264A3", "#7B4BB7"].map((color) => <Pressable key={color} onPress={() => setAccentColor(color)} style={[styles.colorOption, { backgroundColor: color, borderColor: accentColor === color ? colors.foreground : "transparent" }]} accessibilityLabel={`Escolher cor ${color}`} />)}</View>
            <Text style={[styles.settingLabel, { color: colors.muted }]}>Ícone do alerta</Text>
            <View style={styles.settingRow}>{(["waves", "notifications-active"] as const).map((icon) => <Pressable key={icon} onPress={() => setAlertIcon(icon)} style={[styles.settingOption, { backgroundColor: alertIcon === icon ? accentColor : colors.background, borderColor: alertIcon === icon ? accentColor : colors.border }]}><MaterialIcons name={icon} size={19} color={alertIcon === icon ? "#FFFFFF" : colors.foreground} /></Pressable>)}</View>
            <View style={styles.smartAlertHeader}>
              <View style={styles.smartAlertTitleRow}><MaterialIcons name="notifications-active" size={18} color={accentColor} /><Text style={[styles.settingLabel, { color: colors.foreground, marginBottom: 0 }]}>Alertas inteligentes</Text></View>
              <View style={[styles.smartStatus, { backgroundColor: smartAlertsEnabled ? `${colors.success}18` : `${colors.muted}15` }]}><Text style={{ color: smartAlertsEnabled ? colors.success : colors.muted, fontSize: 9, fontWeight: "900" }}>{smartAlertsEnabled ? "ATIVOS" : "DESATIVADOS"}</Text></View>
            </View>
            <Text style={[styles.smartAlertDescription, { color: colors.muted }]}>Avise quando a maré secar totalmente e no melhor pico para sua atividade.</Text>
            <View style={styles.activityRow}>{SMART_ACTIVITIES.map((activity) => <Pressable key={activity.id} onPress={() => setSmartActivity(activity.id)} style={[styles.activityOption, { backgroundColor: smartActivity === activity.id ? accentColor : colors.background, borderColor: smartActivity === activity.id ? accentColor : colors.border }]}><Text style={{ color: smartActivity === activity.id ? "#FFFFFF" : colors.foreground, fontSize: 11, fontWeight: "800" }}>{activity.label}</Text></Pressable>)}</View>
            <Text style={[styles.smartAlertMessage, { color: colors.muted }]}>{smartAlertMessage}</Text>
            <View style={styles.smartAlertActions}>
              <Pressable onPress={scheduleSmartAlerts} style={({ pressed }) => [styles.smartPrimaryButton, { backgroundColor: accentColor }, pressed && styles.pressed]}><MaterialIcons name="notifications-active" size={17} color="#FFFFFF" /><Text style={styles.smartPrimaryText}>{smartAlertsEnabled ? "Atualizar alertas" : "Ativar alertas"}</Text></Pressable>
              {smartAlertsEnabled && <Pressable onPress={cancelSmartAlerts} style={({ pressed }) => [styles.smartSecondaryButton, { borderColor: colors.border }, pressed && styles.pressed]}><Text style={[styles.smartSecondaryText, { color: colors.foreground }]}>Desativar</Text></Pressable>}
            </View>
            <Pressable onPress={testSmartNotification} style={({ pressed }) => [styles.smartTestButton, { borderColor: accentColor }, pressed && styles.pressed]}><MaterialIcons name="notifications-none" size={16} color={accentColor} /><Text style={[styles.smartTestText, { color: accentColor }]}>Testar notificação agora</Text></Pressable>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 22, paddingBottom: 32, gap: 18 },
  header: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between" },
  headerActions: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 1 },
  clockText: { fontSize: 11, fontVariant: ["tabular-nums"] },
  eyebrow: { fontSize: 12, fontWeight: "800", letterSpacing: 1.5, marginBottom: 7 },
  title: { fontSize: 30, lineHeight: 36, fontWeight: "800", letterSpacing: -0.8 },
  livePill: { flexDirection: "row", alignItems: "center", gap: 6, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 7, marginTop: 3 },
  liveDot: { width: 7, height: 7, borderRadius: 4 },
  liveText: { fontSize: 10, fontWeight: "800", letterSpacing: 0.7 },
  themeButton: { width: 32, height: 32, borderRadius: 11, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  statePickerCard: { borderRadius: 18, borderWidth: 1, padding: 14 },
  datePickerCard: { borderRadius: 18, borderWidth: 1, padding: 14 },
  statePickerHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  statePickerLabel: { fontSize: 10, fontWeight: "800", letterSpacing: 1.1, marginBottom: 4 },
  statePickerTitle: { fontSize: 14, fontWeight: "700" },
  stateList: { gap: 8 },
  locationButton: { minHeight: 38, borderRadius: 12, borderWidth: 1, paddingHorizontal: 11, flexDirection: "row", alignItems: "center", gap: 7, marginTop: 12 },
  locationButtonText: { flex: 1, fontSize: 11, fontWeight: "800" },
  stateChip: { minWidth: 44, height: 34, borderRadius: 11, borderWidth: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 11 },
  stateChipText: { fontSize: 12, fontWeight: "800" },
  dateChip: { minWidth: 80, height: 34, borderRadius: 11, borderWidth: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 10 },
  dateChipText: { fontSize: 11, fontWeight: "700", textTransform: "capitalize" },
  calendarButton: { width: 34, height: 34, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  stationCard: { minHeight: 68, borderRadius: 18, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 12, flexDirection: "row", alignItems: "center" },
  stationIcon: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center", marginRight: 11 },
  stationCopy: { flex: 1 },
  stationName: { fontSize: 14, fontWeight: "700", marginBottom: 3 },
  stationSubtitle: { fontSize: 11, lineHeight: 15 },
  officialButton: { minHeight: 46, borderRadius: 15, borderWidth: 1, paddingHorizontal: 13, flexDirection: "row", alignItems: "center", gap: 8 },
  officialButtonText: { flex: 1, fontSize: 12, fontWeight: "800" },
  heroCard: { borderRadius: 24, padding: 22, shadowColor: "#007F9B", shadowOpacity: 0.22, shadowRadius: 20, shadowOffset: { width: 0, height: 8 }, elevation: 6 },
  heroTopRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  heroLabel: { color: "#BDEEF7", fontSize: 11, fontWeight: "800", letterSpacing: 1.1, marginBottom: 5 },
  heroStatus: { color: "#FFFFFF", fontSize: 32, fontWeight: "800", letterSpacing: -0.8 },
  levelRow: { flexDirection: "row", alignItems: "baseline", marginTop: 16, gap: 8 },
  levelValue: { color: "#FFFFFF", fontSize: 46, lineHeight: 53, fontWeight: "800", letterSpacing: -1.5 },
  levelUnit: { color: "#C7F4FA", fontSize: 14, fontWeight: "600" },
  waveTrack: { height: 7, borderRadius: 4, backgroundColor: "#FFFFFF30", overflow: "hidden", marginTop: 16 },
  waveFill: { height: "100%", backgroundColor: "#FFFFFF", borderRadius: 4 },
  heroHint: { color: "#C7F4FA", fontSize: 11, marginTop: 10 },
  extremeAlert: { minHeight: 70, borderRadius: 18, borderWidth: 1, padding: 12, flexDirection: "row", alignItems: "center", gap: 10 },
  extremeAlertIcon: { width: 40, height: 40, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  extremeAlertCopy: { flex: 1 },
  extremeAlertTitle: { fontSize: 14, fontWeight: "800", marginBottom: 3 },
  extremeAlertText: { fontSize: 11, lineHeight: 15 },
  alertBadge: { borderRadius: 9, paddingHorizontal: 8, paddingVertical: 5 },
  alertBadgeText: { color: "#FFFFFF", fontSize: 9, fontWeight: "900", letterSpacing: 0.6 },
  sectionTitle: { fontSize: 18, fontWeight: "800", marginTop: 1 },
  changeGrid: { flexDirection: "row", gap: 12 },
  changeCard: { flex: 1, borderRadius: 18, borderWidth: 1, padding: 14 },
  changeIcon: { width: 32, height: 32, borderRadius: 10, alignItems: "center", justifyContent: "center", marginBottom: 12 },
  changeLabel: { fontSize: 11, fontWeight: "600", lineHeight: 15 },
  changeTime: { fontSize: 24, fontWeight: "800", marginTop: 4 },
  changeDate: { fontSize: 11, marginTop: 2, textTransform: "capitalize" },
  listCard: { borderRadius: 18, borderWidth: 1, overflow: "hidden" },
  eventRow: { minHeight: 69, paddingHorizontal: 14, flexDirection: "row", alignItems: "center" },
  eventIcon: { width: 32, height: 32, borderRadius: 10, alignItems: "center", justifyContent: "center", marginRight: 11 },
  eventMain: { flex: 1 },
  eventType: { fontSize: 14, fontWeight: "700", marginBottom: 3 },
  eventDate: { fontSize: 11, textTransform: "capitalize" },
  eventRight: { alignItems: "flex-end" },
  eventTime: { fontSize: 16, fontWeight: "800", marginBottom: 3 },
  eventLevel: { fontSize: 11 },
  errorCard: { borderWidth: 1, borderRadius: 18, padding: 15, flexDirection: "row", alignItems: "center", gap: 9 },
  errorText: { flex: 1, fontSize: 12, lineHeight: 17 },
  retryButton: { padding: 3 },
  retryText: { fontSize: 12, fontWeight: "800" },
  pressed: { opacity: 0.65 },
  loadingState: { minHeight: 330, alignItems: "center", justifyContent: "center", gap: 14 },
  loadingText: { fontSize: 14 },
  footerRow: { flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 5, marginTop: 2 },
  footerText: { fontSize: 11 },
  developerText: { textAlign: "center", fontSize: 11, marginTop: -8 },
  modalBackdrop: { flex: 1, backgroundColor: "#00000080", justifyContent: "flex-end" },
  modalCard: { borderTopLeftRadius: 26, borderTopRightRadius: 26, padding: 20, paddingBottom: 32, maxHeight: "82%" },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 20 },
  modalEyebrow: { fontSize: 10, fontWeight: "900", letterSpacing: 1.2, marginBottom: 4 },
  modalTitle: { fontSize: 22, fontWeight: "800" },
  modalClose: { width: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: "#00000010" },
  calendarGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  calendarDay: { width: "14%", minWidth: 43, height: 54, borderRadius: 12, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  calendarDayText: { fontSize: 15, fontWeight: "900" },
  calendarWeekday: { fontSize: 9, textTransform: "capitalize", marginTop: 2 },
  settingLabel: { fontSize: 12, fontWeight: "800", marginBottom: 9, marginTop: 5 },
  settingRow: { flexDirection: "row", gap: 10, marginBottom: 14 },
  settingOption: { minWidth: 82, height: 40, borderRadius: 12, borderWidth: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 14 },
  colorOption: { width: 38, height: 38, borderRadius: 19, borderWidth: 3 },
  smartAlertHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 12, marginBottom: 5 },
  smartAlertTitleRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  smartStatus: { borderRadius: 10, paddingHorizontal: 8, paddingVertical: 5 },
  smartAlertDescription: { fontSize: 11, lineHeight: 16, marginBottom: 10 },
  activityRow: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginBottom: 8 },
  activityOption: { borderRadius: 10, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 8 },
  smartAlertMessage: { fontSize: 10, lineHeight: 14, marginBottom: 10 },
  smartAlertActions: { flexDirection: "row", alignItems: "center", gap: 8 },
  smartPrimaryButton: { minHeight: 40, borderRadius: 12, paddingHorizontal: 13, flexDirection: "row", alignItems: "center", gap: 7 },
  smartPrimaryText: { color: "#FFFFFF", fontSize: 11, fontWeight: "900" },
  smartSecondaryButton: { minHeight: 40, borderRadius: 12, borderWidth: 1, paddingHorizontal: 13, alignItems: "center", justifyContent: "center" },
  smartSecondaryText: { fontSize: 11, fontWeight: "800" },
  smartTestButton: { minHeight: 38, borderRadius: 11, borderWidth: 1, paddingHorizontal: 12, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, marginTop: 9 },
  smartTestText: { fontSize: 11, fontWeight: "800" },
  smartCard: { borderRadius: 18, borderWidth: 1, padding: 14 },
  smartCardHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  smartCardIcon: { width: 40, height: 40, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  smartCardCopy: { flex: 1 },
  smartCardTitle: { fontSize: 14, fontWeight: "800" },
  smartCardSubtitle: { fontSize: 10, marginTop: 3 },
  smartCardMessage: { fontSize: 10, lineHeight: 15, marginTop: 10 },
  smartCardActions: { flexDirection: "row", gap: 8, marginTop: 11 },
  smartCardPrimary: { minHeight: 40, flex: 1, borderRadius: 12, paddingHorizontal: 10, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  smartCardSecondary: { minHeight: 40, borderRadius: 12, borderWidth: 1, paddingHorizontal: 13, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
});
