export type TideType = "H" | "L";

export type TideEvent = {
  t: string;
  v: string;
  type: TideType;
};

function parseTideDate(value: string) {
  return new Date(value.replace(" ", "T"));
}

export function deriveTideState(events: TideEvent[], now = new Date()) {
  const ordered = [...events].sort((a, b) => parseTideDate(a.t).getTime() - parseTideDate(b.t).getTime());
  if (!ordered.length) return null;

  let previous = ordered[0];
  let next = ordered[ordered.length - 1];
  for (let index = 0; index < ordered.length - 1; index += 1) {
    const left = parseTideDate(ordered[index].t);
    const right = parseTideDate(ordered[index + 1].t);
    if (left <= now && right >= now) {
      previous = ordered[index];
      next = ordered[index + 1];
      break;
    }
  }

  const previousDate = parseTideDate(previous.t);
  const nextDate = parseTideDate(next.t);
  const fraction = Math.max(0, Math.min(1, (now.getTime() - previousDate.getTime()) / Math.max(1, nextDate.getTime() - previousDate.getTime())));
  const level = Number(previous.v) + (Number(next.v) - Number(previous.v)) * fraction;
  const isRising = previous.type === "L" && next.type === "H";
  const isFalling = previous.type === "H" && next.type === "L";
  const minutesFromPreviousExtreme = Math.abs(now.getTime() - previousDate.getTime()) / 60000;
  const minutesToNextExtreme = Math.abs(nextDate.getTime() - now.getTime()) / 60000;
  const isAtExtreme = minutesFromPreviousExtreme <= 15 || minutesToNextExtreme <= 15;
  const extremeType = minutesFromPreviousExtreme <= 15 ? previous.type : minutesToNextExtreme <= 15 ? next.type : null;
  const status = isAtExtreme ? (extremeType === "H" ? "Cheia" : "Seca") : isRising ? "Enchendo" : isFalling ? "Secando" : previous.type === "H" ? "Cheia" : "Seca";
  const upcoming = ordered.filter((event) => parseTideDate(event.t).getTime() > now.getTime()).slice(0, 4);

  return {
    status,
    isAtExtreme,
    extremeType,
    level,
    previous,
    next,
    upcoming,
    nextLow: upcoming.find((event) => event.type === "L"),
    nextHigh: upcoming.find((event) => event.type === "H"),
  };
}
