import type { TideEvent } from "./tide";

export type SmartActivity = "pesca" | "surf" | "passeio" | "barco";

export type SmartActivityOption = {
  id: SmartActivity;
  label: string;
  idealType: "H" | "L";
  idealLabel: string;
};

export const SMART_ACTIVITIES: SmartActivityOption[] = [
  { id: "pesca", label: "Pesca", idealType: "H", idealLabel: "maré cheia" },
  { id: "surf", label: "Surf", idealType: "H", idealLabel: "pico da maré cheia" },
  { id: "passeio", label: "Passeio na praia", idealType: "L", idealLabel: "maré seca" },
  { id: "barco", label: "Passeio de barco", idealType: "H", idealLabel: "maré cheia" },
];

export function getSmartActivity(id: SmartActivity) {
  return SMART_ACTIVITIES.find((activity) => activity.id === id) ?? SMART_ACTIVITIES[0];
}

export function getSmartAlertEvents(events: TideEvent[], activity: SmartActivity, now = new Date()) {
  const option = getSmartActivity(activity);
  return [...events]
    .filter((event) => new Date(event.t.replace(" ", "T")).getTime() > now.getTime())
    .filter((event) => event.type === "L" || event.type === option.idealType)
    .sort((a, b) => new Date(a.t.replace(" ", "T")).getTime() - new Date(b.t.replace(" ", "T")).getTime())
    .slice(0, 12)
    .map((event) => {
      const isIdeal = event.type === option.idealType;
      return {
        event,
        kind: isIdeal ? "ideal" as const : "seca" as const,
        title: isIdeal ? `Pico ideal para ${option.label}` : "Maré completamente seca",
        body: isIdeal ? `A previsão indica ${option.idealLabel}.` : "A maré estará no nível mais baixo previsto.",
      };
    });
}
