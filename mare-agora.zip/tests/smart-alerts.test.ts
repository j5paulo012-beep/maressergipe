import { describe, expect, it } from "vitest";
import { getSmartAlertEvents } from "../shared/smart-alerts";
import type { TideEvent } from "../shared/tide";

const events: TideEvent[] = [
  { t: "2026-09-21 06:00", v: "0.4", type: "L" },
  { t: "2026-09-21 12:00", v: "1.8", type: "H" },
  { t: "2026-09-21 18:00", v: "0.5", type: "L" },
];

describe("smart tide alerts", () => {
  it("prioriza picos de cheia para pesca e mantém alertas de maré seca", () => {
    const alerts = getSmartAlertEvents(events, "pesca", new Date("2026-09-21T00:00:00"));
    expect(alerts.map((alert) => alert.kind)).toEqual(["seca", "ideal", "seca"]);
    expect(alerts[1].title).toContain("Pesca");
  });

  it("usa maré seca como pico ideal para passeio na praia", () => {
    const alerts = getSmartAlertEvents(events, "passeio", new Date("2026-09-21T00:00:00"));
    expect(alerts[0].kind).toBe("ideal");
    expect(alerts[0].title).toContain("Passeio na praia");
  });
});
