import { describe, expect, it } from "vitest";

import { deriveTideState, type TideEvent } from "../shared/tide";

const events: TideEvent[] = [
  { t: "2026-09-20 10:00", v: "0.20", type: "L" },
  { t: "2026-09-20 16:00", v: "0.80", type: "H" },
  { t: "2026-09-20 22:00", v: "0.30", type: "L" },
];

describe("deriveTideState", () => {
  it("identifica quando a maré está enchendo e a próxima hora de cheia", () => {
    const result = deriveTideState(events, new Date("2026-09-20T13:00:00"));

    expect(result?.status).toBe("Enchendo");
    expect(result?.nextHigh?.t).toBe("2026-09-20 16:00");
    expect(result?.level).toBeCloseTo(0.5, 2);
  });

  it("identifica quando a maré está secando e a próxima hora de seca", () => {
    const result = deriveTideState(events, new Date("2026-09-20T19:00:00"));

    expect(result?.status).toBe("Secando");
    expect(result?.nextLow?.t).toBe("2026-09-20 22:00");
    expect(result?.level).toBeCloseTo(0.55, 2);
  });

  it("ativa o alerta de maré completamente cheia perto do horário extremo", () => {
    const result = deriveTideState(events, new Date("2026-09-20T16:10:00"));

    expect(result?.status).toBe("Cheia");
    expect(result?.isAtExtreme).toBe(true);
    expect(result?.extremeType).toBe("H");
  });

  it("ativa o alerta de maré completamente seca perto do horário extremo", () => {
    const result = deriveTideState(events, new Date("2026-09-20T22:10:00"));

    expect(result?.status).toBe("Seca");
    expect(result?.isAtExtreme).toBe(true);
    expect(result?.extremeType).toBe("L");
  });
});
