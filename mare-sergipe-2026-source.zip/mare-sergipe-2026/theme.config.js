/** @type {const} */
const themeColors = {
  primary: { light: '#087E8B', dark: '#36A9B5' },
  background: { light: '#F7FBFC', dark: '#101C20' },
  surface: { light: '#FFFFFF', dark: '#17282E' },
  foreground: { light: '#11181C', dark: '#ECEDEE' },
  muted: { light: '#687076', dark: '#9BA1A6' },
  border: { light: '#DCE9EC', dark: '#2D4A53' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
