from __future__ import annotations

import json
import re
from pathlib import Path

SOURCE = Path('/home/ubuntu/upload/pasted_content.txt')
OUT = Path('/home/ubuntu/mare-sergipe-2026/data/tides.json')

WEEKDAYS = {'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SÁB', 'DOM'}
MONTHS = [9, 10, 11, 12]


def clean_number(value: str) -> float:
    return float(value.replace(',', '.'))


def split_blocks(lines: list[str]) -> list[tuple[str, list[str]]]:
    starts = [i for i, line in enumerate(lines) if ' - 2026' in line]
    blocks = []
    for pos, start in enumerate(starts):
        end = starts[pos + 1] if pos + 1 < len(starts) else len(lines)
        title = lines[start].strip().split(' (')[0].strip()
        blocks.append((title, lines[start:end]))
    return blocks


def extract_rows(block: list[str]) -> list[dict]:
    month_header = next((i for i, line in enumerate(block) if line.strip() == 'Setembro'), None)
    if month_header is None:
        return []
    body = block[month_header + 4:]
    rows: list[dict] = []
    i = 0
    while i < len(body):
        marker = body[i].strip()
        if not re.fullmatch(r'\d{1,2}', marker):
            i += 1
            continue
        day = int(marker)
        weekday = body[i + 1].strip() if i + 1 < len(body) and body[i + 1].strip() in WEEKDAYS else None
        if weekday is None:
            i += 1
            continue
        j = i + 2
        payload: list[str] = []
        while j < len(body) and not re.fullmatch(r'\d{1,2}', body[j].strip()):
            if body[j].strip() != '':
                payload.append(body[j].strip())
            j += 1
        text = ' '.join(payload)
        times = re.findall(r'(?<!\d)(\d{4})(?!\d)', text)
        heights = re.findall(r'(?<!\d)(-?\d+[\.,]\d{2})(?!\d)', text)
        rows.append({'day': day, 'weekday': weekday, 'times': times[:4], 'heights': [clean_number(h) for h in heights[:4]]})
        i = j
    return rows


def assign_dates(rows: list[dict]) -> list[dict]:
    # The source is arranged in four month columns, each with day d and day d+16.
    # OCR reads each printed row from left to right: Sep d, Sep d+16,
    # Oct d, Oct d+16, Nov d, Nov d+16, Dec d, Dec d+16.
    result = []
    cursor = 0
    for day in range(1, 16):
        for month in MONTHS:
            if cursor >= len(rows):
                break
            row = rows[cursor]
            cursor += 1
            result.append({**row, 'month': month, 'day': day})
            if cursor >= len(rows):
                break
            row = rows[cursor]
            cursor += 1
            result.append({**row, 'month': month, 'day': day + 16})
    # December has a final day 31 after the common 1–15/17–31 grid.
    if cursor < len(rows):
        row = rows[cursor]
        result.append({**row, 'month': 12, 'day': 31})
    return result


def normalize(rows: list[dict], station: str) -> list[dict]:
    output = []
    for row in assign_dates(rows):
        events = []
        for time, height in zip(row['times'], row['heights']):
            events.append({'time': f'{time[:2]}:{time[2:]}', 'height': height})
        if not events:
            continue
        output.append({
            'station': station,
            'date': f"2026-{row['month']:02d}-{row['day']:02d}",
            'weekday': row['weekday'],
            'events': events,
        })
    return output


def main() -> None:
    lines = [line.rstrip('\n') for line in SOURCE.read_text(encoding='utf-8').splitlines()]
    records = []
    for title, block in split_blocks(lines):
        records.extend(normalize(extract_rows(block), title))
    # Keep source metadata beside the normalized records for the app footer.
    payload = {
        'source': 'DG6-63 Original / Tábua de marés 2026',
        'generatedAt': '2026-09-18T21:10:06-03:00',
        'records': records,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f'generated {len(records)} records -> {OUT}')


if __name__ == '__main__':
    main()
