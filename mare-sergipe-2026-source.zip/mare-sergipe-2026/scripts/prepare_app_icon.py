from pathlib import Path
from PIL import Image

source = Path('/home/ubuntu/upload/1789778710563.png')
project = Path('/home/ubuntu/mare-sergipe-2026')
output = project / 'assets/images/icon.png'

image = Image.open(source).convert('RGB')
width, height = image.size
side = min(width, height)
# Keep the lighthouse, wave mark and title in the square icon focal area.
center_y = int(height * 0.31)
left = (width - side) // 2
top = max(0, min(height - side, center_y - side // 2))
cropped = image.crop((left, top, left + side, top + side))
cropped.resize((1024, 1024), Image.Resampling.LANCZOS).save(output, 'PNG', optimize=True)
print(f'created {output} from {source} using crop box {(left, top, left + side, top + side)}')
