from pathlib import Path
from PIL import Image

source = Path('/home/ubuntu/upload/1789778710563.png')
output = Path('/home/ubuntu/mare-sergipe-2026/assets/images/cover.jpg')
image = Image.open(source).convert('RGB')
image.thumbnail((720, 1080), Image.Resampling.LANCZOS)
image.save(output, 'JPEG', quality=82, optimize=True, progressive=True)
print(f'created {output} ({output.stat().st_size} bytes)')
