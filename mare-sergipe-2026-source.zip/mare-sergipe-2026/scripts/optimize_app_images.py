from pathlib import Path
from PIL import Image

assets = Path('/home/ubuntu/mare-sergipe-2026/assets/images')

icon = Image.open(assets / 'icon.png').convert('RGB')
icon.resize((512, 512), Image.Resampling.LANCZOS).save(assets / 'icon-optimized.png', 'PNG', optimize=True)

background = Image.open(assets / 'tide-background.png').convert('RGB')
background.thumbnail((720, 1469), Image.Resampling.LANCZOS)
background.save(assets / 'tide-background.jpg', 'JPEG', quality=76, optimize=True, progressive=True)

for name in ('icon-optimized.png', 'tide-background.jpg'):
    path = assets / name
    print(f'{name}: {path.stat().st_size} bytes')
