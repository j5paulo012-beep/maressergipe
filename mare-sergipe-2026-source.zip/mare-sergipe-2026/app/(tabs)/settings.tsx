import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { Image, Linking, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useThemeContext } from "@/lib/theme-provider";

const OFFICIAL_SOURCE = "https://www.marinha.mil.br/chm/tabuas-de-mare-6";
const ICON_STORAGE_KEY = "mare-icon";
const TEXT_COLOR_STORAGE_KEY = "mare-text-color";
const ICON_COLOR_STORAGE_KEY = "mare-icon-color";
const ICONS = [
  { name: "water", label: "Maré", color: "#087E8B" },
  { name: "anchor", label: "Âncora", color: "#275DAD" },
  { name: "sailing", label: "Vela", color: "#5C4B99" },
  { name: "waves", label: "Ondas", color: "#008C95" },
  { name: "explore", label: "Bússola", color: "#D97706" },
  { name: "wb-sunny", label: "Sol", color: "#E06C2B" },
] as const;
const TEXT_COLORS = [
  { value: "#12343B", label: "Azul profundo" },
  { value: "#16324F", label: "Marinho" },
  { value: "#3D405B", label: "Ardósia" },
  { value: "#111827", label: "Grafite" },
  { value: "#7C2D12", label: "Terracota" },
] as const;
const ICON_COLORS = [
  { value: "#FFFFFF", label: "Branco" },
  { value: "#FDE68A", label: "Sol" },
  { value: "#BAE6FD", label: "Céu" },
  { value: "#BBF7D0", label: "Espuma" },
  { value: "#FBCFE8", label: "Coral" },
] as const;

type IconName = (typeof ICONS)[number]["name"];

export default function SettingsScreen() {
  const colors = useColors();
  const { colorScheme, setColorScheme } = useThemeContext();
  const router = useRouter();
  const [selected, setSelected] = useState<IconName>("water");
  const [textColor, setTextColor] = useState<string>(TEXT_COLORS[0].value);
  const [iconColor, setIconColor] = useState<string>(ICON_COLORS[0].value);

  useEffect(() => {
    AsyncStorage.multiGet([ICON_STORAGE_KEY, TEXT_COLOR_STORAGE_KEY, ICON_COLOR_STORAGE_KEY]).then((values) => {
      const [icon, text, mark] = values.map(([, value]) => value);
      if (icon && ICONS.some((item) => item.name === icon)) setSelected(icon as IconName);
      if (text) setTextColor(text);
      if (mark) setIconColor(mark);
    });
  }, []);

  async function selectIcon(name: IconName) {
    setSelected(name);
    await AsyncStorage.setItem(ICON_STORAGE_KEY, name);
  }

  async function selectTextColor(value: string) {
    setTextColor(value);
    await AsyncStorage.setItem(TEXT_COLOR_STORAGE_KEY, value);
  }

  async function selectIconColor(value: string) {
    setIconColor(value);
    await AsyncStorage.setItem(ICON_COLOR_STORAGE_KEY, value);
  }

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.backButton, { borderColor: colors.border, opacity: pressed ? 0.6 : 1 }]}>
            <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
          </Pressable>
          <View style={styles.headerCopy}><Text style={[styles.kicker, { color: colors.primary }]}>PERSONALIZAÇÃO</Text><Text style={[styles.title, { color: colors.foreground }]}>Configurações</Text></View>
        </View>

        <View style={[styles.previewCard, { backgroundColor: colors.primary }]}>
          <Image source={require("../../assets/images/icon.png")} style={styles.previewIcon} />
          <View style={styles.previewCopy}><Text style={styles.previewTitle}>Seu ícone de maré</Text><Text style={styles.previewSubtitle}>Escolha um símbolo, a cor das letras e a cor dos ícones.</Text></View>
        </View>

        <View style={[styles.themeCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={[styles.themeIcon, { backgroundColor: `${colors.primary}18` }]}><IconSymbol name={colorScheme === "dark" ? "dark-mode" : "wb-sunny"} size={22} color={colors.primary} /></View>
          <View style={styles.themeCopy}><Text style={[styles.themeTitle, { color: colors.foreground }]}>Aparência</Text><Text style={[styles.themeSubtitle, { color: colors.muted }]}>{colorScheme === "dark" ? "Modo noite ativado" : "Modo dia ativado"}</Text></View>
          <Pressable onPress={() => setColorScheme(colorScheme === "dark" ? "light" : "dark")} style={({ pressed }) => [styles.themeToggle, { backgroundColor: colorScheme === "dark" ? colors.primary : colors.border, opacity: pressed ? 0.7 : 1 }]}>
            <View style={[styles.themeThumb, { backgroundColor: colors.background, alignSelf: colorScheme === "dark" ? "flex-end" : "flex-start" }]} />
          </Pressable>
        </View>

        <Text style={[styles.sectionLabel, { color: colors.muted }]}>ÍCONE PERSONALIZADO</Text>
        <View style={styles.iconGrid}>
          {ICONS.map((item) => {
            const active = selected === item.name;
            return <Pressable key={item.name} onPress={() => selectIcon(item.name)} style={({ pressed }) => [styles.iconOption, { backgroundColor: active ? `${item.color}16` : colors.surface, borderColor: active ? item.color : colors.border, opacity: pressed ? 0.72 : 1 }]}>
              <View style={[styles.iconCircle, { backgroundColor: item.color }]}><IconSymbol name={item.name as never} size={24} color="#FFFFFF" /></View>
              <Text style={[styles.iconLabel, { color: colors.foreground }]}>{item.label}</Text>
              {active && <View style={[styles.check, { backgroundColor: item.color }]}><IconSymbol name="check" size={12} color="#FFFFFF" /></View>}
            </Pressable>;
          })}
        </View>

        <Text style={[styles.sectionLabel, { color: colors.muted }]}>COR DAS LETRAS</Text>
        <View style={[styles.colorCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {TEXT_COLORS.map((item) => <Pressable key={item.value} onPress={() => selectTextColor(item.value)} style={({ pressed }) => [styles.colorOption, { opacity: pressed ? 0.65 : 1 }]}>
            <View style={[styles.colorSwatch, { backgroundColor: item.value, borderColor: textColor === item.value ? colors.primary : colors.border }]} />
            <Text style={[styles.colorLabel, { color: colors.foreground }]}>{item.label}</Text>
            {textColor === item.value && <IconSymbol name="check" size={17} color={colors.primary} />}
          </Pressable>)}
        </View>

        <Text style={[styles.sectionLabel, { color: colors.muted }]}>COR DOS ÍCONES</Text>
        <View style={[styles.colorCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {ICON_COLORS.map((item) => <Pressable key={item.value} onPress={() => selectIconColor(item.value)} style={({ pressed }) => [styles.colorOption, { opacity: pressed ? 0.65 : 1 }]}>
            <View style={[styles.colorSwatch, { backgroundColor: item.value, borderColor: iconColor === item.value ? colors.primary : colors.border }]} />
            <Text style={[styles.colorLabel, { color: colors.foreground }]}>{item.label}</Text>
            {iconColor === item.value && <IconSymbol name="check" size={17} color={colors.primary} />}
          </Pressable>)}
        </View>

        <View style={[styles.aboutCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={[styles.aboutIcon, { backgroundColor: `${colors.primary}16` }]}><IconSymbol name="info.circle" size={22} color={colors.primary} /></View>
          <View style={styles.aboutCopy}><Text style={[styles.aboutTitle, { color: colors.foreground }]}>Sobre os dados</Text><Text style={[styles.aboutText, { color: colors.muted }]}>Previsões 2026 para o Terminal Marítimo Inácio Barbosa e a Capitania dos Portos de Sergipe.</Text></View>
        </View>

        <Pressable onPress={() => Linking.openURL(OFFICIAL_SOURCE)} style={({ pressed }) => [styles.sourceLink, { borderColor: colors.border, opacity: pressed ? 0.6 : 1 }]}><IconSymbol name="open-in-new" size={19} color={colors.primary} /><View style={styles.sourceLinkCopy}><Text style={[styles.sourceLinkTitle, { color: colors.foreground }]}>Site oficial da tabela</Text><Text style={[styles.sourceLinkSubtitle, { color: colors.muted }]}>Centro de Hidrografia da Marinha (CHM/DHN)</Text></View><IconSymbol name="chevron.right" size={20} color={colors.muted} /></Pressable>

        <Text style={[styles.credit, { color: colors.muted }]}>Desenvolvido por Paulo do siri</Text>
        <Text style={[styles.version, { color: colors.muted }]}>Maré Sergipe 2026 • versão 1.0</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 18, paddingBottom: 36, gap: 18 },
  header: { flexDirection: "row", alignItems: "center", gap: 13 },
  backButton: { width: 42, height: 42, borderRadius: 14, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  headerCopy: { gap: 2 },
  kicker: { fontSize: 10, fontWeight: "800", letterSpacing: 1.15 },
  title: { fontSize: 26, fontWeight: "800", letterSpacing: -0.5 },
  previewCard: { borderRadius: 22, padding: 18, flexDirection: "row", alignItems: "center", gap: 14 },
  previewIcon: { width: 62, height: 62, borderRadius: 20 },
  previewCopy: { flex: 1 },
  previewTitle: { color: "#FFFFFF", fontSize: 17, fontWeight: "800" },
  previewSubtitle: { color: "rgba(255,255,255,0.75)", fontSize: 12, lineHeight: 17, marginTop: 4 },
  themeCard: { borderRadius: 17, borderWidth: 1, padding: 12, flexDirection: "row", alignItems: "center", gap: 10 },
  themeIcon: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  themeCopy: { flex: 1 },
  themeTitle: { fontSize: 14, fontWeight: "800" },
  themeSubtitle: { fontSize: 11, marginTop: 3 },
  themeToggle: { width: 50, height: 28, borderRadius: 14, padding: 3, justifyContent: "center" },
  themeThumb: { width: 22, height: 22, borderRadius: 11 },
  sectionLabel: { fontSize: 10, fontWeight: "800", letterSpacing: 1.1, marginBottom: -6 },
  iconGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  iconOption: { width: "31.5%", minHeight: 104, borderRadius: 16, borderWidth: 1, alignItems: "center", justifyContent: "center", gap: 7, position: "relative" },
  iconCircle: { width: 44, height: 44, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  iconLabel: { fontSize: 11, fontWeight: "700" },
  check: { position: "absolute", right: 7, top: 7, width: 18, height: 18, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  colorCard: { borderRadius: 17, borderWidth: 1, paddingVertical: 5, paddingHorizontal: 14 },
  colorOption: { minHeight: 42, flexDirection: "row", alignItems: "center", gap: 10 },
  colorSwatch: { width: 24, height: 24, borderRadius: 12, borderWidth: 2 },
  colorLabel: { flex: 1, fontSize: 12, fontWeight: "700" },
  aboutCard: { borderRadius: 17, borderWidth: 1, flexDirection: "row", padding: 14, gap: 11 },
  aboutIcon: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  aboutCopy: { flex: 1 },
  aboutTitle: { fontSize: 14, fontWeight: "800" },
  aboutText: { fontSize: 11, lineHeight: 17, marginTop: 4 },
  sourceLink: { borderWidth: 1, borderRadius: 16, padding: 14, flexDirection: "row", alignItems: "center", gap: 11 },
  sourceLinkCopy: { flex: 1 },
  sourceLinkTitle: { fontSize: 14, fontWeight: "800" },
  sourceLinkSubtitle: { fontSize: 11, lineHeight: 16, marginTop: 2 },
  credit: { textAlign: "center", fontSize: 12, fontWeight: "700", marginTop: 7 },
  version: { textAlign: "center", fontSize: 10, marginTop: -13 },
});
