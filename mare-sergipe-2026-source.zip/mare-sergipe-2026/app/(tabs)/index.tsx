import AsyncStorage from "@react-native-async-storage/async-storage";
import { useFocusEffect, useNavigation, useRouter } from "expo-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Image,
  ImageBackground,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import tideData from "@/data/tides.json";
import { useColors } from "@/hooks/use-colors";

const OFFICIAL_SOURCE = "https://www.marinha.mil.br/chm/tabuas-de-mare-6";
const STATION_TERMINAL = "TERMINAL MARÍTIMO INÁCIO BARBOSA";
const STATION_CAPITANIA = "CAPITANIA DOS PORTOS DE SERGIPE";
const ICON_STORAGE_KEY = "mare-icon";
const TEXT_COLOR_STORAGE_KEY = "mare-text-color";
const ICON_COLOR_STORAGE_KEY = "mare-icon-color";
const ICONS = ["water", "anchor", "sailing", "waves", "explore", "wb-sunny"] as const;
type IconName = (typeof ICONS)[number];
type Station = typeof STATION_TERMINAL | typeof STATION_CAPITANIA;
type Event = { time: string; height: number };
type TideRecord = { station: string; date: string; weekday: string; events: Event[] };

const records = tideData.records as TideRecord[];
const stationOptions: Station[] = [STATION_TERMINAL, STATION_CAPITANIA];
const monthNames = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];

function formatDate(date: string) {
  const [year, month, day] = date.split("-");
  return `${day} ${monthNames[Number(month) - 1]} ${year}`;
}

function getDateFromInput(value: string) {
  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  return match ? `${match[3]}-${match[2]}-${match[1]}` : value;
}

function TideEvent({ event, colors }: { event: Event; colors: ReturnType<typeof useColors> }) {
  const isHigh = event.height >= 1;
  return (
    <View style={styles.eventRow}>
      <View style={[styles.eventDot, { backgroundColor: isHigh ? colors.primary : colors.warning }]} />
      <View style={styles.eventCopy}>
        <Text style={[styles.eventTime, { color: colors.foreground }]}>{event.time}</Text>
        <Text style={[styles.eventLabel, { color: colors.muted }]}>{isHigh ? "preamar" : "baixa-mar"}</Text>
      </View>
      <Text style={[styles.eventHeight, { color: colors.foreground }]}>{event.height.toFixed(2)} m</Text>
    </View>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const navigation = useNavigation();
  const [station, setStation] = useState<Station>(STATION_TERMINAL);
  const [dateInput, setDateInput] = useState("18/09/2026");
  const [selectedIcon, setSelectedIcon] = useState<IconName>("water");
  const [textColor, setTextColor] = useState<string | null>(null);
  const [iconColor, setIconColor] = useState<string>("#FFFFFF");
  const [lastRefresh, setLastRefresh] = useState("agora");
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showCover, setShowCover] = useState(true);

  useEffect(() => {
    navigation.setOptions({ tabBarStyle: showCover ? { display: "none" } : undefined });
    return () => navigation.setOptions({ tabBarStyle: undefined });
  }, [navigation, showCover]);

  useFocusEffect(useCallback(() => {
    AsyncStorage.multiGet([ICON_STORAGE_KEY, TEXT_COLOR_STORAGE_KEY, ICON_COLOR_STORAGE_KEY]).then((values) => {
      const value = values[0][1];
      if (value && ICONS.includes(value as IconName)) setSelectedIcon(value as IconName);
      setTextColor(values[1][1]);
      if (values[2][1]) setIconColor(values[2][1] as string);
    });
  }, []));

  const selectedDate = getDateFromInput(dateInput);
  const record = useMemo(
    () => records.find((item) => item.station === station && item.date === selectedDate),
    [selectedDate, station],
  );
  async function refreshData() {
    setIsRefreshing(true);
    // The packaged table is the offline fallback; a future server sync can replace this payload.
    await new Promise((resolve) => setTimeout(resolve, 450));
    setLastRefresh(new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }));
    setIsRefreshing(false);
  }

  function chooseDate(delta: number) {
    const base = new Date(`${selectedDate}T12:00:00`);
    base.setDate(base.getDate() + delta);
    const iso = base.toISOString().slice(0, 10);
    setDateInput(`${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}`);
  }

  if (showCover) {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-background">
        <ImageBackground source={require("../../assets/images/cover.jpg")} resizeMode="cover" style={styles.cover}>
          <View style={styles.coverShade} />
          <View style={styles.coverContent}>
            <View style={styles.coverTop}><Text style={styles.coverKicker}>SERVIÇO OFICIAL DE MARÉS</Text><Text style={styles.coverTitle}>Costa de Sergipe</Text></View>
            <Pressable onPress={() => setShowCover(false)} style={({ pressed }) => [styles.coverButton, { opacity: pressed ? 0.75 : 1 }]}>
              <Text style={styles.coverButtonText}>Consultar tábua</Text>
              <IconSymbol name="chevron.right" size={20} color="#10262B" />
            </Pressable>
          </View>
        </ImageBackground>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ImageBackground source={require("../../assets/images/tide-background.jpg")} style={styles.backgroundImage} imageStyle={styles.backgroundImageStyle}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.topBar}>
          <View style={styles.brandRow}>
            <Image source={require("../../assets/images/icon.png")} style={styles.brandMark} />
            <View>
              <Text style={[styles.eyebrow, { color: colors.primary }]}>MARÉS • SERGIPE</Text>
              <Text style={[styles.title, { color: textColor ?? colors.foreground }]}>Consulta de hoje</Text>
            </View>
          </View>
          <Pressable onPress={() => router.push("/settings")} style={({ pressed }) => [styles.settingsButton, { borderColor: colors.border, opacity: pressed ? 0.65 : 1 }]}>
            <IconSymbol name="settings.fill" size={21} color={colors.foreground} />
          </Pressable>
        </View>

        <View style={[styles.statusCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.statusCopy}>
            <View style={styles.liveLine}><View style={[styles.liveDot, { backgroundColor: colors.success }]} /><Text style={[styles.statusLabel, { color: textColor ?? colors.foreground }]}>Base oficial carregada</Text></View>
            <Text style={[styles.statusMeta, { color: colors.muted }]}>Tabela DHN 2026 • atualizado {lastRefresh}</Text>
          </View>
          <Pressable onPress={refreshData} disabled={isRefreshing} style={({ pressed }) => [styles.refreshButton, { borderColor: colors.border, opacity: pressed || isRefreshing ? 0.55 : 1 }]}>
            {isRefreshing ? <ActivityIndicator size="small" color={colors.primary} /> : <IconSymbol name="arrow.clockwise" size={18} color={colors.primary} />}
            <Text style={[styles.refreshText, { color: colors.primary }]}>Atualizar</Text>
          </Pressable>
        </View>

        <Text style={[styles.sectionLabel, { color: colors.muted }]}>LOCAL DE REFERÊNCIA</Text>
        <View style={styles.stationRow}>
          {stationOptions.map((item) => {
            const active = station === item;
            return <Pressable key={item} onPress={() => setStation(item)} style={({ pressed }) => [styles.stationChip, { backgroundColor: active ? colors.primary : colors.surface, borderColor: active ? colors.primary : colors.border, opacity: pressed ? 0.8 : 1 }]}>
              <Text style={[styles.stationChipText, { color: active ? "#FFFFFF" : colors.foreground }]}>{item === STATION_TERMINAL ? "Terminal Inácio Barbosa" : "Capitania dos Portos"}</Text>
            </Pressable>;
          })}
        </View>

        <View style={styles.dateHeader}>
          <Text style={[styles.sectionLabel, { color: colors.muted, marginBottom: 0 }]}>DATA DA PREVISÃO</Text>
          <View style={styles.dateActions}>
            <Pressable onPress={() => chooseDate(-1)}><IconSymbol name="chevron.left" size={20} color={colors.muted} /></Pressable>
            <Pressable onPress={() => chooseDate(1)}><IconSymbol name="chevron.right" size={20} color={colors.muted} /></Pressable>
          </View>
        </View>
        <View style={[styles.dateInputWrap, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <IconSymbol name="calendar" size={20} color={colors.primary} />
          <TextInput value={dateInput} onChangeText={setDateInput} placeholder="DD/MM/AAAA" placeholderTextColor={colors.muted} keyboardType="numbers-and-punctuation" style={[styles.dateInput, { color: colors.foreground }]} maxLength={10} />
          <Text style={[styles.yearPill, { color: colors.primary, backgroundColor: `${colors.primary}18` }]}>2026</Text>
        </View>

        <View style={[styles.heroCard, { backgroundColor: colors.primary }]}>
          <View style={styles.heroTop}><Text style={styles.heroKicker}>{record ? record.weekday : "—"}</Text><Text style={styles.heroDate}>{record ? formatDate(selectedDate) : "Data sem registro"}</Text></View>
          <View style={styles.heroBottom}><View><Text style={styles.heroValue}>{record ? `${Math.max(...record.events.map((event) => event.height)).toFixed(2)} m` : "—"}</Text><Text style={styles.heroCaption}>maior altura do dia</Text></View><IconSymbol name={selectedIcon as never} size={62} color={iconColor} /></View>
        </View>

        <View style={styles.eventHeader}><Text style={[styles.sectionTitle, { color: colors.foreground }]}>Movimento da maré</Text><Text style={[styles.eventUnit, { color: colors.muted }]}>hora • altura</Text></View>
        <View style={[styles.eventsCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {record ? record.events.map((event) => <TideEvent key={`${event.time}-${event.height}`} event={event} colors={colors} />) : <View style={styles.emptyState}><IconSymbol name="search" size={28} color={colors.muted} /><Text style={[styles.emptyTitle, { color: colors.foreground }]}>Sem registro para esta data</Text><Text style={[styles.emptyCopy, { color: colors.muted }]}>Confira outra data entre setembro e dezembro de 2026.</Text></View>}
        </View>

        <View style={[styles.infoBox, { borderColor: `${colors.primary}45`, backgroundColor: `${colors.primary}0D` }]}><IconSymbol name="info.circle" size={19} color={colors.primary} /><Text style={[styles.infoText, { color: colors.foreground }]}>Alturas referidas ao nível médio. Para navegação, confirme as condições locais e a publicação oficial.</Text></View>
        <Pressable onPress={() => Linking.openURL(OFFICIAL_SOURCE)} style={({ pressed }) => [styles.sourceButton, { opacity: pressed ? 0.6 : 1 }]}><IconSymbol name="arrow.up.right.square" size={17} color={colors.primary} /><Text style={[styles.sourceText, { color: colors.primary }]}>Abrir tabela oficial da Marinha (DHN)</Text></Pressable>
        <Text style={[styles.footnote, { color: textColor ?? colors.muted }]}>Fonte: DG6-63 Original • coordenadas e referências conforme documento anexado</Text>
      </ScrollView>
      </ImageBackground>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 18, paddingBottom: 34, gap: 16 },
  cover: { flex: 1, justifyContent: "flex-end" },
  coverShade: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(4, 25, 31, 0.22)" },
  coverContent: { flex: 1, justifyContent: "space-between", padding: 24, paddingBottom: 34 },
  coverTop: { paddingTop: 10 },
  coverKicker: { color: "rgba(255,255,255,0.9)", fontSize: 12, fontWeight: "800", letterSpacing: 1.5 },
  coverTitle: { color: "#FFFFFF", fontSize: 30, fontWeight: "800", marginTop: 5, textTransform: "uppercase" },
  coverButton: { backgroundColor: "#FFFFFF", minHeight: 54, borderRadius: 17, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10 },
  coverButtonText: { color: "#10262B", fontSize: 16, fontWeight: "800", textTransform: "uppercase", letterSpacing: 0.5 },
  backgroundImage: { flex: 1 },
  backgroundImageStyle: { opacity: 0.23 },
  topBar: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  brandMark: { width: 46, height: 46, borderRadius: 15 },
  eyebrow: { fontSize: 11, fontWeight: "800", letterSpacing: 1.25 },
  title: { fontSize: 25, fontWeight: "800", letterSpacing: -0.5, marginTop: 2 },
  settingsButton: { width: 42, height: 42, borderRadius: 14, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  statusCard: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 14, borderRadius: 18, borderWidth: 1 },
  statusCopy: { flex: 1 },
  liveLine: { flexDirection: "row", alignItems: "center", gap: 7 },
  liveDot: { width: 8, height: 8, borderRadius: 4 },
  statusLabel: { fontSize: 13, fontWeight: "700" },
  statusMeta: { fontSize: 11, marginTop: 4 },
  refreshButton: { flexDirection: "row", alignItems: "center", gap: 5, borderWidth: 1, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 10 },
  refreshText: { fontSize: 12, fontWeight: "700" },
  sectionLabel: { fontSize: 10, fontWeight: "800", letterSpacing: 1.1, marginBottom: -8 },
  stationRow: { flexDirection: "row", gap: 8 },
  stationChip: { flex: 1, minHeight: 42, borderRadius: 13, borderWidth: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 8 },
  stationChipText: { fontSize: 12, fontWeight: "700", textAlign: "center" },
  dateHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  dateActions: { flexDirection: "row", gap: 14 },
  dateInputWrap: { flexDirection: "row", alignItems: "center", borderRadius: 14, borderWidth: 1, height: 50, paddingHorizontal: 14, gap: 10 },
  dateInput: { flex: 1, fontSize: 16, fontWeight: "700", paddingVertical: 0 },
  yearPill: { fontSize: 11, fontWeight: "800", paddingVertical: 5, paddingHorizontal: 8, borderRadius: 7 },
  heroCard: { borderRadius: 22, padding: 20, minHeight: 150, justifyContent: "space-between" },
  heroTop: { flexDirection: "row", alignItems: "center", gap: 10 },
  heroKicker: { color: "rgba(255,255,255,0.72)", fontSize: 11, fontWeight: "800", letterSpacing: 1 },
  heroDate: { color: "#FFFFFF", fontSize: 14, fontWeight: "700" },
  heroBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end" },
  heroValue: { color: "#FFFFFF", fontSize: 36, fontWeight: "800", letterSpacing: -1 },
  heroCaption: { color: "rgba(255,255,255,0.72)", fontSize: 12, marginTop: 1 },
  eventHeader: { flexDirection: "row", alignItems: "baseline", justifyContent: "space-between" },
  sectionTitle: { fontSize: 18, fontWeight: "800" },
  eventUnit: { fontSize: 11 },
  eventsCard: { borderRadius: 18, borderWidth: 1, paddingHorizontal: 16 },
  eventRow: { flexDirection: "row", alignItems: "center", minHeight: 60, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: "rgba(128,128,128,0.2)" },
  eventDot: { width: 9, height: 9, borderRadius: 5, marginRight: 12 },
  eventCopy: { flex: 1 },
  eventTime: { fontSize: 17, fontWeight: "800" },
  eventLabel: { fontSize: 11, marginTop: 1 },
  eventHeight: { fontSize: 16, fontWeight: "800" },
  emptyState: { alignItems: "center", paddingVertical: 28, paddingHorizontal: 18 },
  emptyTitle: { fontSize: 15, fontWeight: "800", marginTop: 10 },
  emptyCopy: { fontSize: 12, textAlign: "center", marginTop: 5, lineHeight: 18 },
  infoBox: { flexDirection: "row", gap: 9, borderWidth: 1, borderRadius: 14, padding: 12, alignItems: "flex-start" },
  infoText: { flex: 1, fontSize: 11, lineHeight: 17 },
  sourceButton: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 4 },
  sourceText: { fontSize: 13, fontWeight: "800" },
  footnote: { fontSize: 10, lineHeight: 15, textAlign: "center", marginTop: -6 },
});
