import { describe, expect, it } from "vitest";
import tideData from "./tides.json";

describe("tábua de marés de Sergipe", () => {
  it("carrega registros para os dois pontos oficiais", () => {
    const stations = new Set(tideData.records.map((record) => record.station));
    expect(stations.has("TERMINAL MARÍTIMO INÁCIO BARBOSA")).toBe(true);
    expect(stations.has("CAPITANIA DOS PORTOS DE SERGIPE")).toBe(true);
  });

  it("contém a previsão de 18 de setembro de 2026", () => {
    const record = tideData.records.find(
      (item) => item.station === "TERMINAL MARÍTIMO INÁCIO BARBOSA" && item.date === "2026-09-18",
    );
    expect(record?.events).toEqual([
      { time: "02:02", height: 0.84 },
      { time: "08:34", height: 1.52 },
      { time: "14:44", height: 1.01 },
      { time: "20:49", height: 1.54 },
    ]);
  });

  it("mantém alturas numéricas e horários HH:MM", () => {
    for (const record of tideData.records) {
      for (const event of record.events) {
        expect(event.time).toMatch(/^\d{2}:\d{2}$/);
        expect(typeof event.height).toBe("number");
      }
    }
  });
});
