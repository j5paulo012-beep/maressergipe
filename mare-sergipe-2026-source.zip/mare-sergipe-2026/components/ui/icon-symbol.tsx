// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type MaterialIconName = ComponentProps<typeof MaterialIcons>["name"];

const MAPPING: Record<string, MaterialIconName> = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "settings.fill": "settings",
  water: "water",
  anchor: "anchor",
  sailing: "sailing",
  waves: "waves",
  explore: "explore",
  "wb-sunny": "wb-sunny",
  "dark-mode": "dark-mode",
  "arrow.clockwise": "refresh",
  "chevron.left": "chevron-left",
  calendar: "calendar-today",
  search: "search",
  "info.circle": "info-outline",
  "arrow.up.right.square": "open-in-new",
  "open-in-new": "open-in-new",
  check: "check",
};

type IconSymbolName = keyof typeof MAPPING;

/**
 * An icon component that uses Material Icons on Android and web.
 * The names above provide a small, stable cross-platform icon vocabulary.
 */
export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
